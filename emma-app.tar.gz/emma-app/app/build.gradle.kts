plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.dagger.hilt.android")
    id("kotlin-kapt")
}

android {
    namespace = "com.emma"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.emma"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // API Keys
        buildConfigField("String", "GEMINI_API_KEY", "\"${getApiKey("GEMINI_API_KEY")}\"")
        buildConfigField("String", "PICOVOICE_ACCESS_KEY", "\"${getApiKey("PICOVOICE_ACCESS_KEY")}\"")
        buildConfigField("String", "GOOGLE_SEARCH_API_KEY", "\"${getApiKey("GOOGLE_SEARCH_API_KEY")}\"")
        buildConfigField("String", "GOOGLE_SEARCH_CX", "\"${getApiKey("GOOGLE_SEARCH_CX")}\"")
        buildConfigField("String", "WAKE_WORD_MODEL", "\"hey-emma_android.ppn\"")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        buildConfig = true
        compose = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.0"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    // Android Core
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.lifecycle:lifecycle-service:2.7.0")
    implementation("androidx.activity:activity-compose:1.8.2")
    implementation("androidx.appcompat:appcompat:1.6.1")

    // Compose
    implementation(platform("androidx.compose:compose-bom:2023.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    // Navigation
    implementation("androidx.navigation:navigation-compose:2.7.6")

    // Hilt DI
    implementation("com.google.dagger:hilt-android:2.48")
    kapt("com.google.dagger:hilt-compiler:2.48")
    implementation("androidx.hilt:hilt-navigation-compose:1.1.0")

    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")

    // Gemini
    implementation("com.google.ai.client.generativeai:generativeai:0.1.2")

    // Porcupine Wake Word
    implementation("ai.picovoice:porcupine-android:3.0.1")

    // Networking
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")

    // DataStore
    implementation("androidx.datastore:datastore-preferences:1.0.0")

    // Timber Logging
    implementation("com.jakewharton.timber:timber:5.0.1")

    // Permissions
    implementation("com.google.accompanist:accompanist-permissions:0.32.0")
}

kapt {
    correctErrorTypes = true
}

// Helper function to read API keys
fun getApiKey(key: String): String {
    val localProps = java.util.Properties()
    val localFile = rootProject.file("local.properties")
    if (localFile.exists()) {
        localFile.inputStream().use { localProps.load(it) }
        val value = localProps.getProperty(key)
        if (value != null && value.isNotBlank() && !value.contains("your_")) {
            return value
        }
    }
    val gradleValue = project.findProperty(key) as? String
    if (gradleValue != null && gradleValue.isNotBlank() && !gradleValue.contains("your_")) {
        return gradleValue
    }
    println("WARNING: API key $key not found")
    return "NOT_CONFIGURED"
}
