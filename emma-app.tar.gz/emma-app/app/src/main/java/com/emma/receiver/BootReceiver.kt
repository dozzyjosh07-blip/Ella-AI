package com.emma.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.emma.service.WakeWordService
import timber.log.Timber

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            Timber.i("Boot completed - starting Emma wake word service")
            context.startService(Intent(context, WakeWordService::class.java).apply {
                action = WakeWordService.ACTION_START
            })
        }
    }
}
