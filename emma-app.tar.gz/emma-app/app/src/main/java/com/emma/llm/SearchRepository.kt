package com.emma.llm

import com.emma.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SearchRepository @Inject constructor(private val okHttpClient: OkHttpClient) {

    suspend fun search(query: String, numResults: Int = 5): SearchResult = withContext(Dispatchers.IO) {
        try {
            if (BuildConfig.GOOGLE_SEARCH_API_KEY == "NOT_CONFIGURED" || BuildConfig.GOOGLE_SEARCH_CX.isBlank()) {
                return@withContext SearchResult.Error("Search not configured")
            }

            val url = buildString {
                append("https://www.googleapis.com/customsearch/v1")
                append("?key=${BuildConfig.GOOGLE_SEARCH_API_KEY}")
                append("&cx=${BuildConfig.GOOGLE_SEARCH_CX}")
                append("&q=${java.net.URLEncoder.encode(query, "UTF-8")}")
                append("&num=$numResults")
            }

            val request = Request.Builder().url(url).get().build()
            val response = okHttpClient.newCall(request).execute()
            val body = response.body?.string()

            if (!response.isSuccessful || body == null) {
                return@withContext SearchResult.Error("Search failed: ${response.code}")
            }

            val json = JSONObject(body)
            val items = json.optJSONArray("items")

            if (items == null || items.length() == 0) {
                return@withContext SearchResult.Success(emptyList())
            }

            val results = mutableListOf<SearchItem>()
            for (i in 0 until items.length()) {
                val item = items.getJSONObject(i)
                results.add(SearchItem(
                    title = item.optString("title", ""),
                    link = item.optString("link", ""),
                    snippet = item.optString("snippet", "")
                ))
            }

            SearchResult.Success(results)
        } catch (e: Exception) {
            Timber.e(e, "Search error")
            SearchResult.Error("Search error: ${e.message}")
        }
    }
}

sealed class SearchResult {
    data class Success(val items: List<SearchItem>) : SearchResult()
    data class Error(val message: String) : SearchResult()
}

data class SearchItem(val title: String, val link: String, val snippet: String)
