package com.emma

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.emma.model.ConversationState
import com.emma.screen.ScreenCaptureManager
import com.emma.service.ConversationService
import com.emma.service.WakeWordService
import com.emma.ui.theme.EmmaTheme
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import dagger.hilt.android.AndroidEntryPoint
import timber.log.Timber
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject
    lateinit var screenCaptureManager: ScreenCaptureManager

    private var conversationState by mutableStateOf<ConversationState>(ConversationState.Idle)

    private val wakeWordReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == WakeWordService.ACTION_WAKE_WORD_DETECTED) {
                Timber.i("Wake word detected")
            }
        }
    }

    private val conversationReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                ConversationService.ACTION_CONVERSATION_ENDED -> {
                    conversationState = ConversationState.Idle
                }
            }
        }
    }

    private val screenCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            val projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val projection = projectionManager.getMediaProjection(result.resultCode, result.data!!)
            screenCaptureManager.setMediaProjection(projection)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        registerReceiver(wakeWordReceiver, IntentFilter(WakeWordService.ACTION_WAKE_WORD_DETECTED))
        registerReceiver(conversationReceiver, IntentFilter(ConversationService.ACTION_CONVERSATION_ENDED))

        setContent {
            EmmaTheme {
                EmmaApp(
                    conversationState = conversationState,
                    onStartWakeWord = { startWakeWordService() },
                    onStopWakeWord = { stopWakeWordService() },
                    onStartConversation = { startConversation() },
                    onStopConversation = { stopConversation() },
                    onRequestScreenCapture = { requestScreenCapture() },
                    onOpenSettings = { openAccessibilitySettings() }
                )
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(wakeWordReceiver)
        unregisterReceiver(conversationReceiver)
    }

    private fun startWakeWordService() {
        startService(Intent(this, WakeWordService::class.java).apply {
            action = WakeWordService.ACTION_START
        })
    }

    private fun stopWakeWordService() {
        startService(Intent(this, WakeWordService::class.java).apply {
            action = WakeWordService.ACTION_STOP
        })
    }

    private fun startConversation() {
        startService(Intent(this, ConversationService::class.java).apply {
            action = ConversationService.ACTION_START_CONVERSATION
        })
    }

    private fun stopConversation() {
        startService(Intent(this, ConversationService::class.java).apply {
            action = ConversationService.ACTION_STOP_CONVERSATION
        })
    }

    private fun requestScreenCapture() {
        screenCaptureLauncher.launch(screenCaptureManager.createCaptureIntent())
    }

    private fun openAccessibilitySettings() {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }
}

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun EmmaApp(
    conversationState: ConversationState,
    onStartWakeWord: () -> Unit,
    onStopWakeWord: () -> Unit,
    onStartConversation: () -> Unit,
    onStopConversation: () -> Unit,
    onRequestScreenCapture: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val context = LocalContext.current
    val permissionsState = rememberMultiplePermissionsState(
        permissions = listOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)
    )

    var wakeWordEnabled by remember { mutableStateOf(false) }
    val canDrawOverlays = Settings.canDrawOverlays(context)

    LaunchedEffect(Unit) {
        if (!permissionsState.allPermissionsGranted) {
            permissionsState.launchMultiplePermissionRequest()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Emma", fontWeight = FontWeight.Bold, fontSize = 24.sp) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                ),
                actions = {
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = MaterialTheme.colorScheme.onPrimary)
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            StatusCard(conversationState)

            MainControls(
                wakeWordEnabled = wakeWordEnabled,
                onWakeWordToggle = { enabled ->
                    wakeWordEnabled = enabled
                    if (enabled) onStartWakeWord() else onStopWakeWord()
                },
                onStartConversation = onStartConversation,
                onStopConversation = onStopConversation,
                conversationState = conversationState
            )

            PermissionsCard(
                permissionsGranted = permissionsState.allPermissionsGranted,
                overlayGranted = canDrawOverlays,
                onRequestPermissions = { permissionsState.launchMultiplePermissionRequest() },
                onRequestOverlay = {
                    context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
                }
            )

            ScreenCaptureCard(onRequestScreenCapture = onRequestScreenCapture)
        }
    }
}

@Composable
fun StatusCard(state: ConversationState) {
    val (statusText, statusColor, icon) = when (state) {
        is ConversationState.Idle -> Triple("Idle", Color.Gray, Icons.Default.PowerSettingsNew)
        is ConversationState.Listening -> Triple("Listening...", Color.Green, Icons.Default.Mic)
        is ConversationState.Processing -> Triple("Processing...", Color.Blue, Icons.Default.Psychology)
        is ConversationState.Speaking -> Triple("Speaking", Color.Magenta, Icons.Default.VolumeUp)
        is ConversationState.ExecutingTool -> Triple("Executing...", Color.Yellow, Icons.Default.Build)
        is ConversationState.Error -> Triple("Error", Color.Red, Icons.Default.Error)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = statusColor.copy(alpha = 0.1f)),
        shape = MaterialTheme.shapes.medium
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(icon, contentDescription = null, tint = statusColor, modifier = Modifier.size(32.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Text(statusText, fontSize = 20.sp, fontWeight = FontWeight.Medium, color = statusColor)
        }
    }
}

@Composable
fun MainControls(
    wakeWordEnabled: Boolean,
    onWakeWordToggle: (Boolean) -> Unit,
    onStartConversation: () -> Unit,
    onStopConversation: () -> Unit,
    conversationState: ConversationState
) {
    Card(modifier = Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.medium) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Controls", fontSize = 18.sp, fontWeight = FontWeight.Bold)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Hearing, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Wake Word Detection")
                }
                Switch(checked = wakeWordEnabled, onCheckedChange = onWakeWordToggle)
            }

            Divider()

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Button(
                    onClick = onStartConversation,
                    enabled = conversationState is ConversationState.Idle,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Green)
                ) {
                    Icon(Icons.Default.Mic, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Start")
                }

                Button(
                    onClick = onStopConversation,
                    enabled = conversationState !is ConversationState.Idle,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                ) {
                    Icon(Icons.Default.Stop, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Stop")
                }
            }
        }
    }
}

@Composable
fun PermissionsCard(
    permissionsGranted: Boolean,
    overlayGranted: Boolean,
    onRequestPermissions: () -> Unit,
    onRequestOverlay: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.medium) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Permissions", fontSize = 18.sp, fontWeight = FontWeight.Bold)

            PermissionRow("Microphone & Camera", permissionsGranted, onRequestPermissions)
            PermissionRow("Draw Over Apps", overlayGranted, onRequestOverlay)
        }
    }
}

@Composable
fun PermissionRow(label: String, granted: Boolean, onRequest: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (granted) Icons.Default.CheckCircle else Icons.Default.Warning,
                contentDescription = null,
                tint = if (granted) Color.Green else Color.Red
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(label)
        }
        if (!granted) {
            TextButton(onClick = onRequest) { Text("Grant") }
        }
    }
}

@Composable
fun ScreenCaptureCard(onRequestScreenCapture: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.medium) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Screen Capture", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text("Allow Emma to see your screen for visual assistance", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(onClick = onRequestScreenCapture, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.ScreenShare, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Grant Screen Capture Permission")
            }
        }
    }
}
