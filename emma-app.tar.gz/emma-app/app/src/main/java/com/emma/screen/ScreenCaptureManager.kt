package com.emma.screen

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.Looper
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.resume

@Singleton
class ScreenCaptureManager @Inject constructor(@ApplicationContext private val context: Context) {
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private val handler = Handler(Looper.getMainLooper())

    private val projectionManager by lazy {
        context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    }

    fun createCaptureIntent(): Intent = projectionManager.createScreenCaptureIntent()

    fun setMediaProjection(projection: MediaProjection) {
        mediaProjection = projection
    }

    suspend fun captureScreen(): Bitmap = withContext(Dispatchers.Default) {
        val projection = mediaProjection ?: throw IllegalStateException("MediaProjection not set")
        val metrics = context.resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        virtualDisplay = projection.createVirtualDisplay(
            "EmmaScreenCapture", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, handler
        )

        val bitmap = withTimeoutOrNull(5000) {
            suspendCancellableCoroutine<Bitmap> { continuation ->
                imageReader?.setOnImageAvailableListener({ reader ->
                    try {
                        val image = reader.acquireLatestImage()
                        if (image != null) {
                            val planes = image.planes
                            val buffer = planes[0].buffer
                            val pixelStride = planes[0].pixelStride
                            val rowStride = planes[0].rowStride
                            val rowPadding = rowStride - pixelStride * image.width

                            val bitmap = Bitmap.createBitmap(
                                image.width + rowPadding / pixelStride,
                                image.height, Bitmap.Config.ARGB_8888
                            )
                            bitmap.copyPixelsFromBuffer(buffer)

                            val result = if (rowPadding > 0) {
                                Bitmap.createBitmap(bitmap, 0, 0, image.width, image.height).also { bitmap.recycle() }
                            } else bitmap

                            image.close()
                            continuation.resume(result)
                        }
                    } catch (e: Exception) {
                        Timber.e(e, "Error capturing screen")
                    }
                }, handler)
            }
        } ?: throw IllegalStateException("Screen capture timeout")

        cleanup()
        bitmap
    }

    fun isReady(): Boolean = mediaProjection != null

    private fun cleanup() {
        virtualDisplay?.release()
        imageReader?.close()
        virtualDisplay = null
        imageReader = null
    }

    fun release() {
        cleanup()
        mediaProjection?.stop()
        mediaProjection = null
    }
}

fun Bitmap.toBase64(quality: Int = 85): String {
    val outputStream = java.io.ByteArrayOutputStream()
    compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
    return android.util.Base64.encodeToString(outputStream.toByteArray(), android.util.Base64.DEFAULT)
}
