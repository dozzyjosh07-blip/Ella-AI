package com.emma.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.emma.MainActivity
import com.emma.R
import com.emma.audio.FullDuplexAudioController
import com.emma.llm.GeminiConversationRepository
import com.emma.model.ConversationState
import com.emma.model.GptMessage
import com.emma.model.ScreenContext
import com.emma.model.ToolCall
import com.emma.model.ToolResult
import com.emma.screen.ScreenCaptureManager
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import timber.log.Timber
import java.io.ByteArrayOutputStream
import javax.inject.Inject
import android.util.Base64

@AndroidEntryPoint
class ConversationService : Service() {
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val binder = ConversationBinder()

    @Inject lateinit var audioController: FullDuplexAudioController
    @Inject lateinit var geminiRepository: GeminiConversationRepository
    @Inject lateinit var screenCaptureManager: ScreenCaptureManager
    @Inject lateinit var toolExecutor: com.emma.device.ToolExecutor
    @Inject lateinit var accessibilityController: AccessibilityController

    private val _conversationState = MutableStateFlow<ConversationState>(ConversationState.Idle)
    val conversationState: StateFlow<ConversationState> = _conversationState.asStateFlow()

    private var currentJob: Job? = null
    private var isActive = false

    companion object {
        const val ACTION_START_CONVERSATION = "com.emma.action.START_CONVERSATION"
        const val ACTION_STOP_CONVERSATION = "com.emma.action.STOP_CONVERSATION"
        const val ACTION_USER_INTERRUPT = "com.emma.action.USER_INTERRUPT"
        const val ACTION_CONVERSATION_ENDED = "com.emma.CONVERSATION_ENDED"
    }

    inner class ConversationBinder : Binder() {
        fun getService(): ConversationService = this@ConversationService
        fun getState(): StateFlow<ConversationState> = conversationState
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_CONVERSATION -> startConversation()
            ACTION_STOP_CONVERSATION -> stopConversation()
            ACTION_USER_INTERRUPT -> handleUserInterrupt()
        }
        return START_NOT_STICKY
    }

    private fun createNotification(content: String = "Active conversation"): Notification {
        val pendingIntent = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stopIntent = PendingIntent.getService(this, 1, Intent(this, ConversationService::class.java).apply {
            action = ACTION_STOP_CONVERSATION
        }, PendingIntent.FLAG_IMMUTABLE)

        return NotificationCompat.Builder(this, "emma_conversation")
            .setContentTitle("Emma")
            .setContentText(content)
            .setSmallIcon(R.drawable.ic_assistant)
            .setContentIntent(pendingIntent)
            .addAction(R.drawable.ic_close, "Stop", stopIntent)
            .setOngoing(true)
            .build()
    }

    private fun startConversation() {
        if (isActive) return
        isActive = true
        startForeground(1002, createNotification("Listening..."))

        currentJob?.cancel()
        currentJob = serviceScope.launch { runConversationLoop() }
    }

    private suspend fun runConversationLoop() {
        try {
            audioController.initializeStream()
            _conversationState.value = ConversationState.Listening

            audioController.userTranscriptFlow.collectLatest { transcript ->
                if (transcript.isBlank()) return@collectLatest
                Timber.d("User said: $transcript")
                _conversationState.value = ConversationState.Processing

                val screenContext = if (shouldCaptureScreen(transcript)) captureScreenContext() else null
                processWithGemini(transcript, screenContext)
            }
        } catch (e: Exception) {
            Timber.e(e, "Conversation loop error")
            _conversationState.value = ConversationState.Error(e.message ?: "Unknown error")
        }
    }

    private fun shouldCaptureScreen(transcript: String): Boolean {
        return listOf("screen", "what do you see", "look at", "show me", "what's on", "can you see", "describe")
            .any { transcript.contains(it, ignoreCase = true) }
    }

    private suspend fun captureScreenContext(): ScreenContext? = try {
        updateNotification("Capturing screen...")
        val bitmap = screenCaptureManager.captureScreen()
        ScreenContext(System.currentTimeMillis(), bitmapToBase64(bitmap), "Current screen content")
    } catch (e: Exception) {
        Timber.e(e, "Screen capture failed")
        null
    }

    private fun bitmapToBase64(bitmap: android.graphics.Bitmap): String {
        val outputStream = ByteArrayOutputStream()
        bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, outputStream)
        return Base64.encodeToString(outputStream.toByteArray(), Base64.DEFAULT)
    }

    private suspend fun processWithGemini(transcript: String, screenContext: ScreenContext?) {
        try {
            val message = GptMessage(role = "user", content = transcript, imageBase64 = screenContext?.imageBase64)
            val response = geminiRepository.sendMessage(message)

            if (response.toolCalls.isNotEmpty()) {
                handleToolCalls(response.toolCalls)
            }

            if (response.content.isNotBlank()) {
                _conversationState.value = ConversationState.Speaking(response.content)
                updateNotification(response.content)
                speakResponse(response.content)
            }

            _conversationState.value = ConversationState.Listening
            updateNotification("Listening...")
        } catch (e: Exception) {
            Timber.e(e, "Gemini processing error")
            _conversationState.value = ConversationState.Error("Sorry, I encountered an error")
        }
    }

    private suspend fun handleToolCalls(toolCalls: List<ToolCall>) {
        for (toolCall in toolCalls) {
            Timber.d("Executing tool: ${toolCall.name}")
            _conversationState.value = ConversationState.ExecutingTool(toolCall.name)
            val result = executeTool(toolCall)
            geminiRepository.sendToolResult(toolCall.id, result)
        }
    }

    private suspend fun executeTool(toolCall: ToolCall): ToolResult = try {
        when (toolCall.name) {
            "turn_on_flashlight" -> toolExecutor.turnOnFlashlight()
            "turn_off_flashlight" -> toolExecutor.turnOffFlashlight()
            "set_volume" -> toolExecutor.setVolume((toolCall.arguments["level"] as? Number)?.toInt() ?: 50)
            "open_app" -> toolExecutor.openApp(toolCall.arguments["packageName"] as? String ?: "")
            "search_google" -> toolExecutor.searchGoogle(toolCall.arguments["query"] as? String ?: "")
            "send_whatsapp_message" -> accessibilityController.sendWhatsAppMessage(
                toolCall.arguments["contact"] as? String ?: "",
                toolCall.arguments["message"] as? String ?: ""
            )
            "play_spotify_song" -> accessibilityController.playSongOnSpotify(toolCall.arguments["song"] as? String ?: "")
            else -> ToolResult.Error("Unknown tool: ${toolCall.name}")
        }
    } catch (e: Exception) {
        Timber.e(e, "Tool execution error: ${toolCall.name}")
        ToolResult.Error("Failed: ${e.message}")
    }

    private suspend fun speakResponse(text: String) {
        try {
            audioController.speak(text) {}
        } catch (e: Exception) {
            Timber.e(e, "TTS error")
        }
    }

    private fun handleUserInterrupt() {
        serviceScope.launch {
            audioController.stopSpeaking()
            _conversationState.value = ConversationState.Listening
            updateNotification("Listening...")
            geminiRepository.sendInterruption()
        }
    }

    private fun stopConversation() {
        isActive = false
        currentJob?.cancel()
        serviceScope.launch {
            audioController.release()
            _conversationState.value = ConversationState.Idle
            sendBroadcast(Intent(ACTION_CONVERSATION_ENDED))
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun updateNotification(content: String) {
        androidx.core.app.NotificationManagerCompat.from(this).notify(1002, createNotification(content))
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        audioController.release()
    }
}

interface AccessibilityController {
    suspend fun sendWhatsAppMessage(contactName: String, message: String): ToolResult
    suspend fun playSongOnSpotify(songName: String): ToolResult
}
