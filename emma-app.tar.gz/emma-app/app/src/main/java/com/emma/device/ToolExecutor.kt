package com.emma.device

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import com.emma.model.ToolResult
import dagger.hilt.android.qualifiers.ApplicationContext
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ToolExecutor @Inject constructor(@ApplicationContext private val context: Context) {
    private val cameraManager by lazy { context.getSystemService(Context.CAMERA_SERVICE) as CameraManager }
    private val audioManager by lazy { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    private var cameraId: String? = null
    private var flashlightOn = false

    init {
        try {
            for (id in cameraManager.cameraIdList) {
                if (cameraManager.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true) {
                    cameraId = id
                    break
                }
            }
        } catch (e: CameraAccessException) {
            Timber.e(e, "Camera init error")
        }
    }

    fun turnOnFlashlight(): ToolResult = try {
        cameraId?.let {
            cameraManager.setTorchMode(it, true)
            flashlightOn = true
            ToolResult.Success("Flashlight on")
        } ?: ToolResult.Error("No flashlight available")
    } catch (e: CameraAccessException) {
        ToolResult.Error("Failed: ${e.message}")
    }

    fun turnOffFlashlight(): ToolResult = try {
        cameraId?.let {
            cameraManager.setTorchMode(it, false)
            flashlightOn = false
            ToolResult.Success("Flashlight off")
        } ?: ToolResult.Error("No flashlight available")
    } catch (e: CameraAccessException) {
        ToolResult.Error("Failed: ${e.message}")
    }

    fun setVolume(level: Int, streamType: Int = AudioManager.STREAM_MUSIC): ToolResult = try {
        val maxVolume = audioManager.getStreamMaxVolume(streamType)
        val targetVolume = (level * maxVolume / 100).coerceIn(0, maxVolume)
        audioManager.setStreamVolume(streamType, targetVolume, AudioManager.FLAG_SHOW_UI)
        ToolResult.Success("Volume set to $level%")
    } catch (e: Exception) {
        ToolResult.Error("Failed: ${e.message}")
    }

    fun openApp(packageName: String): ToolResult = try {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            ?: return ToolResult.Error("App not found: $packageName")
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        context.startActivity(intent)
        ToolResult.Success("Opened $packageName")
    } catch (e: Exception) {
        ToolResult.Error("Failed: ${e.message}")
    }

    fun searchGoogle(query: String): ToolResult = try {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}"))
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        context.startActivity(intent)
        ToolResult.Success("Searching: $query")
    } catch (e: Exception) {
        ToolResult.Error("Failed: ${e.message}")
    }

    fun openUrl(url: String): ToolResult = try {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
        context.startActivity(intent)
        ToolResult.Success("Opening: $url")
    } catch (e: Exception) {
        ToolResult.Error("Failed: ${e.message}")
    }
}

object AppPackages {
    const val WHATSAPP = "com.whatsapp"
    const val SPOTIFY = "com.spotify.music"
    const val YOUTUBE = "com.google.android.youtube"
    const val GMAIL = "com.google.android.gm"
    const val MAPS = "com.google.android.apps.maps"
    const val CHROME = "com.android.chrome"
}
