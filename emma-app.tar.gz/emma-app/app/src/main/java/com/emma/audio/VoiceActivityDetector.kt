package com.emma.audio

import kotlin.math.sqrt

typealias SpeechCallback = (Boolean) -> Unit

class VoiceActivityDetector(
    private val sampleRate: Int,
    private val frameSize: Int,
    private val threshold: Float,
    private val onSpeechDetected: SpeechCallback
) {
    private val buffer = ShortArray(frameSize)
    private var bufferIndex = 0
    private var speechFrameCount = 0
    private var silenceFrameCount = 0
    private var isInSpeech = false
    private val speechFramesRequired = 3
    private val silenceFramesRequired = 15

    fun process(audioData: ByteArray) {
        val shorts = bytesToShorts(audioData)
        for (sample in shorts) {
            if (bufferIndex < frameSize) {
                buffer[bufferIndex++] = sample
            }
            if (bufferIndex >= frameSize) {
                processFrame()
                bufferIndex = 0
            }
        }
    }

    private fun processFrame() {
        val energy = calculateEnergy(buffer)
        val isSpeech = energy > threshold

        if (isSpeech) {
            speechFrameCount++
            silenceFrameCount = 0
            if (!isInSpeech && speechFrameCount >= speechFramesRequired) {
                isInSpeech = true
                onSpeechDetected(true)
            }
        } else {
            silenceFrameCount++
            if (isInSpeech && silenceFrameCount >= silenceFramesRequired) {
                isInSpeech = false
                speechFrameCount = 0
            }
        }
    }

    private fun calculateEnergy(frame: ShortArray): Float {
        var sum = 0.0
        for (sample in frame) {
            sum += sample * sample
        }
        return sqrt(sum / frame.size).toFloat() / Short.MAX_VALUE
    }

    private fun bytesToShorts(bytes: ByteArray): ShortArray {
        val shorts = ShortArray(bytes.size / 2)
        for (i in shorts.indices) {
            shorts[i] = ((bytes[i * 2 + 1].toInt() shl 8) or (bytes[i * 2].toInt() and 0xFF)).toShort()
        }
        return shorts
    }

    fun reset() {
        bufferIndex = 0
        speechFrameCount = 0
        silenceFrameCount = 0
        isInSpeech = false
    }
}
