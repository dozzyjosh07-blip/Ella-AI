package com.emma.model

import android.graphics.Bitmap
import java.util.UUID

sealed class ConversationState {
    data object Idle : ConversationState()
    data object Listening : ConversationState()
    data object Processing : ConversationState()
    data class Speaking(val text: String) : ConversationState()
    data class ExecutingTool(val toolName: String) : ConversationState()
    data class Error(val message: String) : ConversationState()
}

data class GptMessage(
    val id: String = UUID.randomUUID().toString(),
    val role: String,
    val content: String,
    val toolCallId: String? = null,
    val toolCalls: List<ToolCall>? = null,
    val imageBase64: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

data class ToolCall(
    val id: String,
    val name: String,
    val arguments: Map<String, Any>
)

data class GptResponse(
    val content: String,
    val toolCalls: List<ToolCall> = emptyList()
)

data class FunctionTool(
    val name: String,
    val description: String,
    val parameters: Map<String, ToolParameter>
)

data class ToolParameter(
    val type: String,
    val description: String,
    val required: Boolean = false,
    val enum: List<String>? = null
)

sealed class ToolResult {
    data class Success(val message: String) : ToolResult()
    data class Error(val message: String) : ToolResult()
}

data class ScreenContext(
    val timestamp: Long,
    val imageBase64: String,
    val description: String
)
