package com.emma.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.emma.MainActivity
import com.emma.R
import com.emma.screen.ScreenCaptureManager
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class ScreenCaptureService : Service() {
    @Inject lateinit var screenCaptureManager: ScreenCaptureManager

    companion object {
        const val ACTION_START = "com.emma.action.START_SCREEN_CAPTURE"
        const val ACTION_STOP = "com.emma.action.STOP_SCREEN_CAPTURE"
    }

    override fun onCreate() {
        super.onCreate()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startScreenCapture()
            ACTION_STOP -> {
                stopScreenCapture()
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun createNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, "emma_screen_capture")
            .setContentTitle("Emma Screen Capture")
            .setContentText("Screen capture is active")
            .setSmallIcon(R.drawable.ic_screen)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun startScreenCapture() {
        startForeground(1003, createNotification())
    }

    private fun stopScreenCapture() {
        screenCaptureManager.release()
    }

    override fun onDestroy() {
        super.onDestroy()
        screenCaptureManager.release()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
