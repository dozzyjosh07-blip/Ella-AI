package com.emma.di

import android.content.Context
import com.emma.audio.FullDuplexAudioController
import com.emma.device.ToolExecutor
import com.emma.llm.ConversationMemoryManager
import com.emma.llm.GeminiConversationRepository
import com.emma.llm.SearchRepository
import com.emma.screen.ScreenCaptureManager
import com.google.ai.client.generativeai.GenerativeModel
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import timber.log.Timber
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideOkHttpClient(): OkHttpClient {
        return OkHttpClient.Builder()
            .addInterceptor(HttpLoggingInterceptor { message -> Timber.tag("OkHttp").d(message) }.apply {
                level = HttpLoggingInterceptor.Level.BASIC
            })
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    @Provides
    @Singleton
    fun provideGeminiModel(): GenerativeModel {
        return GenerativeModel(
            modelName = "gemini-1.5-flash",
            apiKey = com.emma.BuildConfig.GEMINI_API_KEY
        )
    }

    @Provides
    @Singleton
    fun provideConversationMemoryManager(@ApplicationContext context: Context): ConversationMemoryManager {
        return ConversationMemoryManager(context)
    }

    @Provides
    @Singleton
    fun provideGeminiConversationRepository(
        geminiModel: GenerativeModel,
        memoryManager: ConversationMemoryManager,
        searchRepository: SearchRepository
    ): GeminiConversationRepository {
        return GeminiConversationRepository(geminiModel, memoryManager, searchRepository)
    }

    @Provides
    @Singleton
    fun provideFullDuplexAudioController(
        @ApplicationContext context: Context,
        geminiModel: GenerativeModel
    ): FullDuplexAudioController {
        return FullDuplexAudioController(context, geminiModel)
    }

    @Provides
    @Singleton
    fun provideScreenCaptureManager(@ApplicationContext context: Context): ScreenCaptureManager {
        return ScreenCaptureManager(context)
    }

    @Provides
    @Singleton
    fun provideToolExecutor(@ApplicationContext context: Context): ToolExecutor {
        return ToolExecutor(context)
    }

    @Provides
    @Singleton
    fun provideSearchRepository(okHttpClient: OkHttpClient): SearchRepository {
        return SearchRepository(okHttpClient)
    }
}
