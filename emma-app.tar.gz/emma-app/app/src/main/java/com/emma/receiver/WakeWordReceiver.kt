package com.emma.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import timber.log.Timber

class WakeWordReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            "com.emma.WAKE_WORD_DETECTED" -> {
                Timber.i("Wake word detected broadcast received")
            }
        }
    }
}
