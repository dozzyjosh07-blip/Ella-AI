package com.emma

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import dagger.hilt.android.HiltAndroidApp
import timber.log.Timber

@HiltAndroidApp
class EmmaApplication : Application() {

    override fun onCreate() {
        super.onCreate()

        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }

        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val channels = listOf(
                NotificationChannel("emma_wake_word", "Wake Word Detection", NotificationManager.IMPORTANCE_LOW),
                NotificationChannel("emma_conversation", "Active Conversation", NotificationManager.IMPORTANCE_HIGH),
                NotificationChannel("emma_screen_capture", "Screen Capture", NotificationManager.IMPORTANCE_LOW),
                NotificationChannel("emma_overlay", "Emma Overlay", NotificationManager.IMPORTANCE_HIGH)
            )

            channels.forEach { channel ->
                channel.setSound(null, null)
                notificationManager.createNotificationChannel(channel)
            }
        }
    }
}
