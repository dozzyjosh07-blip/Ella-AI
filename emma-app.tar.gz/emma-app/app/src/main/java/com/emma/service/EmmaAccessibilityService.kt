package com.emma.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.emma.model.ToolResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import timber.log.Timber
import kotlin.coroutines.resume

class EmmaAccessibilityService : AccessibilityService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var currentPackageName: String? = null

    companion object {
        @Volatile
        var instance: EmmaAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        serviceInfo = serviceInfo.apply {
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or
                    AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            notificationTimeout = 100
        }
        Timber.i("Accessibility service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event?.let {
            if (it.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                currentPackageName = it.packageName?.toString()
            }
        }
    }

    override fun onInterrupt() {
        Timber.w("Accessibility service interrupted")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    fun findNodeByText(text: String, root: AccessibilityNodeInfo? = rootInActiveWindow, partialMatch: Boolean = true): AccessibilityNodeInfo? {
        if (root == null) return null
        val nodes = root.findAccessibilityNodeInfosByText(text)
        return nodes.firstOrNull { node ->
            if (partialMatch) {
                node.text?.contains(text, true) == true || node.contentDescription?.contains(text, true) == true
            } else {
                node.text?.toString() == text || node.contentDescription?.toString() == text
            }
        }
    }

    fun findNodeById(viewId: String, root: AccessibilityNodeInfo? = rootInActiveWindow): AccessibilityNodeInfo? {
        if (root == null) return null
        return root.findAccessibilityNodeInfosByViewId(viewId).firstOrNull()
    }

    fun findEditText(root: AccessibilityNodeInfo? = rootInActiveWindow): AccessibilityNodeInfo? {
        return findNodeRecursive(root) { it.isEditable && it.className?.contains("EditText") == true }
    }

    fun clickNode(node: AccessibilityNodeInfo?): Boolean = node?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false

    fun clickAt(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 100)).build()
        return dispatchGesture(gesture, null, null)
    }

    fun typeText(node: AccessibilityNodeInfo?, text: String): Boolean {
        if (node == null) return false
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        })
    }

    fun swipe(startX: Float, startY: Float, endX: Float, endY: Float, duration: Long = 300): Boolean {
        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, duration)).build()
        return dispatchGesture(gesture, null, null)
    }

    suspend fun waitForNode(predicate: (AccessibilityNodeInfo) -> Boolean, timeoutMs: Long = 5000): AccessibilityNodeInfo? {
        return withTimeoutOrNull(timeoutMs) {
            suspendCancellableCoroutine { continuation ->
                scope.launch {
                    while (true) {
                        val node = findNodeRecursive(rootInActiveWindow, predicate)
                        if (node != null) {
                            continuation.resume(node)
                            return@launch
                        }
                        delay(100)
                    }
                }
            }
        }
    }

    private fun findNodeRecursive(node: AccessibilityNodeInfo?, predicate: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (node == null) return null
        if (predicate(node)) return node
        for (i in 0 until node.childCount) {
            val result = findNodeRecursive(node.getChild(i), predicate)
            if (result != null) return result
        }
        return null
    }
}

class AccessibilityControllerImpl(private val service: EmmaAccessibilityService?) : AccessibilityController {
    override suspend fun sendWhatsAppMessage(contactName: String, message: String): ToolResult {
        val svc = service ?: return ToolResult.Error("Accessibility service not available")
        return try {
            openApp("com.whatsapp")
            delay(1500)

            val searchNode = svc.waitForNode {
                it.contentDescription?.toString()?.contains("search", true) == true ||
                        it.text?.toString()?.contains("Search", true) == true
            } ?: return ToolResult.Error("Search button not found")

            svc.clickNode(searchNode)
            delay(500)

            val searchField = svc.findEditText() ?: return ToolResult.Error("Search field not found")
            svc.typeText(searchField, contactName)
            delay(1000)

            val contactNode = svc.waitForNode { it.text?.toString()?.contains(contactName, true) == true }
                ?: return ToolResult.Error("Contact not found")
            svc.clickNode(contactNode)
            delay(500)

            val messageField = svc.waitForNode { it.isEditable && it.className?.contains("EditText") == true }
                ?: return ToolResult.Error("Message input not found")
            svc.typeText(messageField, message)
            delay(300)

            val sendButton = svc.waitForNode {
                it.contentDescription?.toString()?.contains("send", true) == true ||
                        it.viewIdResourceName?.contains("send") == true
            } ?: return ToolResult.Error("Send button not found")

            if (svc.clickNode(sendButton)) ToolResult.Success("Message sent to $contactName")
            else ToolResult.Error("Failed to send message")
        } catch (e: Exception) {
            ToolResult.Error("Error: ${e.message}")
        }
    }

    override suspend fun playSongOnSpotify(songName: String): ToolResult {
        val svc = service ?: return ToolResult.Error("Accessibility service not available")
        return try {
            openApp("com.spotify.music")
            delay(2000)

            val searchTab = svc.waitForNode { it.contentDescription?.toString()?.contains("search", true) == true }
                ?: return ToolResult.Error("Search tab not found")
            svc.clickNode(searchTab)
            delay(500)

            val searchField = svc.findEditText() ?: return ToolResult.Error("Search field not found")
            svc.typeText(searchField, songName)
            delay(1000)

            val firstResult = svc.waitForNode {
                it.isClickable && (it.text?.toString()?.contains(songName, true) == true ||
                        it.contentDescription?.toString()?.contains(songName, true) == true)
            } ?: return ToolResult.Error("Song not found")

            if (svc.clickNode(firstResult)) ToolResult.Success("Playing $songName")
            else ToolResult.Error("Failed to play song")
        } catch (e: Exception) {
            ToolResult.Error("Error: ${e.message}")
        }
    }

    private fun openApp(packageName: String): Boolean {
        val context = EmmaAccessibilityService.instance?.applicationContext ?: return false
        val intent = context.packageManager.getLaunchIntentForPackage(packageName) ?: return false
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        context.startActivity(intent)
        return true
    }
}
