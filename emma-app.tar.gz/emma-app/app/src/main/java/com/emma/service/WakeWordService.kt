package com.emma.service

import ai.picovoice.porcupine.PorcupineManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import com.emma.MainActivity
import com.emma.R
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import timber.log.Timber
import javax.inject.Inject

@AndroidEntryPoint
class WakeWordService : Service() {
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var porcupineManager: PorcupineManager? = null
    private var audioRecord: AudioRecord? = null
    private var isListening = false
    private var wakeLock: PowerManager.WakeLock? = null

    @Inject
    lateinit var conversationController: ConversationController

    companion object {
        const val ACTION_START = "com.emma.action.START_WAKE_WORD"
        const val ACTION_STOP = "com.emma.action.STOP_WAKE_WORD"
        const val ACTION_WAKE_WORD_DETECTED = "com.emma.WAKE_WORD_DETECTED"
    }

    override fun onCreate() {
        super.onCreate()
        initializePorcupine()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startWakeWordDetection()
            ACTION_STOP -> {
                stopWakeWordDetection()
                stopSelf()
            }
            else -> startWakeWordDetection()
        }
        return START_STICKY
    }

    private fun createNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, "emma_wake_word")
            .setContentTitle("Emma is listening")
            .setContentText("Say 'Hey Emma' to activate")
            .setSmallIcon(R.drawable.ic_mic)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun initializePorcupine() {
        try {
            porcupineManager = PorcupineManager.Builder()
                .setAccessKey(com.emma.BuildConfig.PICOVOICE_ACCESS_KEY)
                .setKeywordPath(com.emma.BuildConfig.WAKE_WORD_MODEL)
                .setSensitivity(0.7f)
                .build(applicationContext) { onWakeWordDetected() }
            Timber.d("Porcupine initialized")
        } catch (e: Exception) {
            Timber.e(e, "Porcupine init failed, trying fallback")
            tryFallbackPorcupine()
        }
    }

    private fun tryFallbackPorcupine() {
        val keywords = listOf("porcupine", "hey google", "hey siri", "alexa")
        for (keyword in keywords) {
            try {
                porcupineManager = PorcupineManager.Builder()
                    .setAccessKey(com.emma.BuildConfig.PICOVOICE_ACCESS_KEY)
                    .setKeywordPath("$keyword_android.ppn")
                    .setSensitivity(0.7f)
                    .build(applicationContext) { onWakeWordDetected() }
                Timber.d("Porcupine fallback success: $keyword")
                return
            } catch (e: Exception) {
                continue
            }
        }
        Timber.e("All Porcupine fallbacks failed")
    }

    private fun startWakeWordDetection() {
        startForeground(1001, createNotification())

        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Emma::WakeWord")
        wakeLock?.acquire(30 * 60 * 1000L)

        serviceScope.launch { startAudioCapture() }
    }

    private suspend fun startAudioCapture() {
        val sampleRate = 16000
        val frameLength = 512
        val minBufferSize = AudioRecord.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )

        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.MIC, sampleRate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
            maxOf(minBufferSize, frameLength * 2)
        )

        if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
            Timber.e("AudioRecord failed to initialize")
            return
        }

        audioRecord?.startRecording()
        isListening = true
        val buffer = ShortArray(frameLength)

        withContext(Dispatchers.IO) {
            while (isListening && audioRecord?.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                try {
                    val readResult = audioRecord?.read(buffer, 0, frameLength) ?: 0
                    if (readResult == frameLength) {
                        porcupineManager?.process(buffer)
                    }
                } catch (e: Exception) {
                    Timber.e(e, "Audio read error")
                }
            }
        }
    }

    private fun onWakeWordDetected() {
        Timber.i("Wake word detected!")
        vibrate()
        sendBroadcast(Intent(ACTION_WAKE_WORD_DETECTED))
        startService(Intent(this, ConversationService::class.java).apply {
            action = ConversationService.ACTION_START_CONVERSATION
        })
    }

    private fun vibrate() {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as android.os.VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION") getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(100, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION") vibrator.vibrate(100)
            }
        } catch (e: Exception) {
            Timber.e(e, "Vibrate failed")
        }
    }

    private fun stopWakeWordDetection() {
        isListening = false
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        try {
            audioRecord?.stop()
            audioRecord?.release()
        } catch (e: Exception) {
            Timber.e(e, "AudioRecord stop error")
        }
        audioRecord = null
    }

    override fun onDestroy() {
        super.onDestroy()
        stopWakeWordDetection()
        serviceScope.cancel()
        try {
            porcupineManager?.delete()
        } catch (e: Exception) {
            Timber.e(e, "Porcupine delete error")
        }
        porcupineManager = null
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

interface ConversationController {
    fun startConversation()
    fun stopConversation()
    fun onConversationEnded()
}
