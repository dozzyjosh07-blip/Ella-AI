package com.emma.audio

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.google.ai.client.generativeai.GenerativeModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.util.Locale
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FullDuplexAudioController @Inject constructor(
    @ApplicationContext private val context: Context,
    private val geminiModel: GenerativeModel
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var textToSpeech: TextToSpeech? = null
    private var isSpeaking = false
    private var isInitialized = false

    private val _userTranscriptFlow = MutableSharedFlow<String>(replay = 0)
    val userTranscriptFlow: SharedFlow<String> = _userTranscriptFlow.asSharedFlow()

    fun initializeStream() {
        if (isInitialized) return
        setupTextToSpeech()
        isInitialized = true
    }

    private fun setupTextToSpeech() {
        textToSpeech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech?.apply {
                    language = Locale.US
                    setSpeechRate(1.0f)
                    setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) { isSpeaking = true }
                        override fun onDone(utteranceId: String?) { isSpeaking = false }
                        override fun onError(utteranceId: String?) { isSpeaking = false }
                    })
                }
                Timber.d("TTS initialized")
            } else {
                Timber.e("TTS initialization failed")
            }
        }
    }

    suspend fun processTextInput(text: String) {
        if (text.isNotBlank()) {
            _userTranscriptFlow.emit(text)
        }
    }

    suspend fun speak(text: String, onProgress: (Float) -> Unit = {}) = withContext(Dispatchers.Main) {
        try {
            textToSpeech?.let { tts ->
                isSpeaking = true
                val utteranceId = UUID.randomUUID().toString()
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
            }
        } catch (e: Exception) {
            Timber.e(e, "Error speaking text")
            isSpeaking = false
        }
    }

    fun stopSpeaking() {
        isSpeaking = false
        textToSpeech?.stop()
    }

    fun isCurrentlySpeaking(): Boolean = isSpeaking

    fun release() {
        scope.cancel()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        textToSpeech = null
    }
}
