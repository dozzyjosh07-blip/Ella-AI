package com.emma.llm

import android.graphics.Bitmap
import com.emma.model.FunctionTool
import com.emma.model.GptMessage
import com.emma.model.GptResponse
import com.emma.model.ToolCall
import com.emma.model.ToolParameter
import com.emma.model.ToolResult
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GeminiConversationRepository @Inject constructor(
    private val geminiModel: GenerativeModel,
    private val memoryManager: ConversationMemoryManager,
    private val searchRepository: SearchRepository
) {
    private val tools = listOf(
        FunctionTool("turn_on_flashlight", "Turn on the device flashlight", emptyMap()),
        FunctionTool("turn_off_flashlight", "Turn off the device flashlight", emptyMap()),
        FunctionTool("set_volume", "Set the device volume level (0-100)", mapOf("level" to ToolParameter("integer", "Volume level from 0 to 100", true))),
        FunctionTool("open_app", "Open a specific application", mapOf("packageName" to ToolParameter("string", "Android package name (e.g., com.whatsapp)", true))),
        FunctionTool("search_google", "Search Google for information", mapOf("query" to ToolParameter("string", "Search query", true))),
        FunctionTool("send_whatsapp_message", "Send a WhatsApp message", mapOf("contact" to ToolParameter("string", "Contact name", true), "message" to ToolParameter("string", "Message content", true))),
        FunctionTool("play_spotify_song", "Play a song on Spotify", mapOf("song" to ToolParameter("string", "Song name or artist", true))),
        FunctionTool("increase_volume", "Increase the device volume", mapOf("steps" to ToolParameter("integer", "Number of steps", false))),
        FunctionTool("decrease_volume", "Decrease the device volume", mapOf("steps" to ToolParameter("integer", "Number of steps", false))),
        FunctionTool("open_url", "Open a URL in the browser", mapOf("url" to ToolParameter("string", "URL to open", true)))
    )

    private val systemPrompt = """You are Emma, a helpful AI assistant for Android devices. You can:
1. Control device functions (flashlight, volume, open apps)
2. Send messages via WhatsApp
3. Play music on Spotify
4. Search Google for information
5. See and analyze the user's screen when they ask
Be concise, friendly, and helpful. Current date: ${java.util.Date()}""".trimIndent()

    init {
        memoryManager.addMessage(GptMessage(role = "system", content = systemPrompt))
    }

    suspend fun sendMessage(message: GptMessage): GptResponse = withContext(Dispatchers.IO) {
        Timber.d("Sending message to Gemini: ${message.content.take(100)}...")
        memoryManager.addMessage(message)

        try {
            val history = buildHistory()
            val chat = geminiModel.startChat(history = history)
            val response = chat.sendMessage(content { text(message.content) })

            val responseText = StringBuilder()
            response.candidates.firstOrNull()?.content?.parts?.forEach { part ->
                if (part is com.google.ai.client.generativeai.type.TextPart) {
                    responseText.append(part.text)
                }
            }

            val gptResponse = GptResponse(content = responseText.toString(), toolCalls = emptyList())
            memoryManager.addMessage(GptMessage(role = "assistant", content = gptResponse.content))
            gptResponse
        } catch (e: Exception) {
            Timber.e(e, "Error calling Gemini API")
            GptResponse(content = "I'm sorry, I encountered an error. Please try again.", toolCalls = emptyList())
        }
    }

    suspend fun analyzeScreen(bitmap: Bitmap, userQuery: String = "What do you see on this screen?"): String = withContext(Dispatchers.IO) {
        try {
            val content = content {
                text(userQuery)
                image(bitmap)
            }
            geminiModel.generateContent(content).text ?: "I'm not sure what I'm seeing."
        } catch (e: Exception) {
            Timber.e(e, "Error analyzing screen")
            "I encountered an error while trying to analyze your screen."
        }
    }

    suspend fun sendToolResult(toolCallId: String, result: ToolResult): GptResponse = withContext(Dispatchers.IO) {
        val resultText = when (result) {
            is ToolResult.Success -> result.message
            is ToolResult.Error -> "Error: ${result.message}"
        }
        memoryManager.addMessage(GptMessage(role = "tool", content = resultText, toolCallId = toolCallId))
        GptResponse(content = "I've completed the action. $resultText", toolCalls = emptyList())
    }

    suspend fun sendInterruption() {
        memoryManager.addMessage(GptMessage(role = "system", content = "The user interrupted. Pause and listen to their new request."))
    }

    private fun buildHistory(): List<com.google.ai.client.generativeai.type.Content> {
        return memoryManager.getRecentMessages(20).filter { it.role != "system" }.map { msg ->
            content(role = if (msg.role == "user") "user" else "model") { text(msg.content) }
        }
    }

    fun clearConversation() {
        memoryManager.clear()
        memoryManager.addMessage(GptMessage(role = "system", content = systemPrompt))
    }
}
