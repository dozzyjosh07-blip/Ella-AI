package com.emma.llm

import android.content.Context
import com.emma.model.GptMessage
import com.emma.model.ToolCall
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ConversationMemoryManager @Inject constructor(
    private val context: Context
) {
    private val inMemoryMessages = mutableListOf<GptMessage>()
    private val _messagesFlow = MutableStateFlow<List<GptMessage>>(emptyList())
    val messagesFlow: StateFlow<List<GptMessage>> = _messagesFlow.asStateFlow()

    @Synchronized
    fun addMessage(message: GptMessage) {
        inMemoryMessages.add(message)
        if (inMemoryMessages.size > 50) {
            val systemMessages = inMemoryMessages.filter { it.role == "system" }
            val recentMessages = inMemoryMessages.filter { it.role != "system" }.takeLast(40)
            inMemoryMessages.clear()
            inMemoryMessages.addAll(systemMessages)
            inMemoryMessages.addAll(recentMessages)
        }
        _messagesFlow.value = inMemoryMessages.toList()
        Timber.d("Added message: ${message.role}")
    }

    fun getRecentMessages(count: Int): List<GptMessage> {
        return inMemoryMessages.takeLast(count)
    }

    fun getAllMessages(): List<GptMessage> {
        return inMemoryMessages.toList()
    }

    fun clear() {
        inMemoryMessages.clear()
        _messagesFlow.value = emptyList()
        Timber.d("Conversation memory cleared")
    }

    fun getConversationSummary(): String {
        val userMessages = inMemoryMessages.count { it.role == "user" }
        val assistantMessages = inMemoryMessages.count { it.role == "assistant" }
        return "Total: ${inMemoryMessages.size} messages (User: $userMessages, Assistant: $assistantMessages)"
    }
}
